# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ext-web/quickpricer/quick-pricerinternal/reg_ts01_tc06_01_create-or-send-pdf-button-appears-at-the-bottom-with-the-select-1597.spec.ts >> Quick Pricer Module- Row 1 >> REG_TS01_TC06_01 - Create or send PDF button appears at the bottom with the select
- Location: tests/ext-web/quickpricer/quick-pricerinternal/reg_ts01_tc06_01_create-or-send-pdf-button-appears-at-the-bottom-with-the-select-1597.spec.ts:41:11

# Error details

```
TimeoutError: locator.click: Timeout 35000ms exceeded.
Call log:
  - waiting for locator('//label[@for="results-columnsQuickPricer"]')
    - locator resolved to <label class="outer" for="results-columnsQuickPricer">…</label>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <modal-container role="dialog" tabindex="-1" aria-modal="true" class="modal fade show">…</modal-container> intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <modal-container role="dialog" tabindex="-1" aria-modal="true" class="modal fade show">…</modal-container> intercepts pointer events
    - retrying click action
      - waiting 100ms
    66 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <modal-container role="dialog" tabindex="-1" aria-modal="true" class="modal fade show">…</modal-container> intercepts pointer events
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e8]:
    - banner [ref=e11]:
      - navigation [ref=e13]:
        - img "Logo" [ref=e16] [cursor=pointer]
        - generic [ref=e17]: "Version: 1.0"
        - generic [ref=e18]:
          - list [ref=e19]:
            - listitem [ref=e20]:
              - link "Rate Alerts" [ref=e21] [cursor=pointer]:
                - /url: https://salesstgdemo.cre8techdev.com/#/ext/rate-alerts?tk=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ0ZXN0c2lnbWFsb2NrIiwiYWxsb3dFeHBvcnRXaGVuRmlsZUxvY2tlZCI6dHJ1ZSwiZGxwUHJvSW50ZWdyYXRpb24iOnsiZW5hYmxlZCI6ZmFsc2UsImxpbmtJZCI6IjY1Y2QyOGNlMmY3ZTdkNjkxODczNDE4YyIsImRscFByb0NvbXBhbnlJZCI6bnVsbCwiZGxwUHJvVXNlcklkIjpudWxsfSwiZXh0ZXJuYWxDb21wYW55Tm1scyI6bnVsbCwiZW5mb3JjZW1lbnRNb2RlIjoiU1RSSUNUIiwiZGV2aWNlSWQiOiIxZDA4YTJmYy1jYzZlLTQ5ODMtYjg1Yy1hNmNjNjgwNDg0YzYiLCJlbmFibGVkIjp0cnVlLCJjbGllbnRfaWQiOiJwcGUtbGVuZGVycHJpY2UiLCJjb21wYW55VXNlclR5cGUiOiJDb21wYW55VXNlciIsInN0YW5kQWxvbmUiOnRydWUsImZlYXR1cmVzIjp7ImJsb2NrVWkiOnRydWUsImxvYW5BY2Nlc3NDb250cm9sIjpmYWxzZSwic3luY1N0YXR1c01hbmFnZW1lbnQiOmZhbHNlLCJmdWxsRXBjQ29tcGF0aWJsZSI6ZmFsc2UsInBpcGVsaW5lVmlldyI6dHJ1ZSwicGlwZWxpbmVNb25pdG9yaW5nVmlldyI6dHJ1ZSwibWNwQWNjZXNzIjp0cnVlfSwib3ZlcnJpZGVVc2VyR3JvdXAiOm51bGwsImV4dGVybmFsQ29tcGFueVRwb0lkIjpudWxsLCJmZWF0dXJlR3JvdXBzIjpbXSwic2NvcGUiOlsiZGVmYXVsdCJdLCJjb250ZXh0IjpudWxsLCJleHAiOjE3ODEzMDExNDMsImp0aSI6IjNlMTk2NGJmLWIwZDQtNDRlYS1hZGQ4LTAxY2NjN2E3NTRiYyIsImVtYWlsIjoic3VwcG9ydCt0ZXN0c2lnbWFsb2NrQGxlbmRlcnByaWNlLmNvbSIsImNvbXBhbnlObWxzSWQiOiIwMDAwMSIsInJlc2V0UGFzc3dvcmRSZXF1aXJlZCI6ZmFsc2UsInBhc3N3b3JkUmVxdWVzdElkIjpudWxsLCJsb2FuT2ZmaWNlck5tbHNJZCI6bnVsbCwidXNlcklkIjoiNjVjZDI4Y2UyZjdlN2Q2OTE4NzM0MTg5IiwiYXV0aG9yaXRpZXMiOlsiQ29tcGFueUV4Y2VsTWFwcGluZ0NvbmZpZyIsIk1pZ3JhdGlvbkFkbWluIiwiQ29tcGFueVByaWNpbmciLCJEb3dubG9hZExpbmtlZFJhdGUiLCJUcmFjZVByb2R1Y3QiLCJDb21wYW55VXNlclByaWNlUXVvdGUiLCJDb21wYW55Vmlld01hcmdpblJlbGF0aW9uIiwiQ29tcGFueVVzZXJHcm91cE1hbmFnZXIiLCJDYW5WaWV3RHluYW1pY0NvbHVtbkVkaXQiLCJGb3JjZVN5bmNoIiwiRWRpdEF2ZXJhZ2VDcmVkaXQiLCJVc2VyUmV2aWV3IiwiQXBwcmFpc2FsVmFsdWUiLCJFbXBsb3llZUxvYW4iLCJBbGxvd0FJTEFDb25maWd1cmF0aW9uIiwiQ2FuUHJpY2VJUlJSTG9hbnMiLCJIZWxvYyIsIkxvY2tEZXNrIiwiQ2FuUHJpY2VDb25zdHJ1Y3Rpb25Mb2FucyIsIlZpZXdRdWFsaWZpZXIiLCJDb21wYW55VXNlclZpZXciLCJWaWV3R3VhcmFudGVlRmVlIiwiRGVidWdQcmljZXIiLCJBZHZhbmNlU2VhcmNoIiwiQWZmaW5pdHlQcmljaW5nIiwiQ29tcGFueUFkanVzdG1lbnRHcm91cCIsIkNvbXBhbnlVc2VyQWRtaW4iLCJDb21wYW55VXNlclJhdGVBbGVydE1hbmFnZXIiLCJDYW5JbXBlcnNvbmF0ZUFsbFVzZXJzIiwiRGVidWdQcmljZXJTZWFyY2giLCJDb21wYW55RXhjZWxDb21wYXJpc29uVG9vbCIsIkNhblRyYWNrVGltZSIsIkNvbXBhbnlDb21wbGlhbmNlRWRpdCIsIkNvbXBhbnlEZWxldGVSYXRlIiwiTG9hbk9mZmljZXIiLCJDb21wYW55TWFuYWdlQnJva2VycyIsIkNvbXBhbnlWaWV3RGFzaGJvYXJkIiwiQ29udGFjdExlbmRlciIsIkNvbXBhbnlVc2VyU2NoZWR1bGVSYXRlUGVyaW9kTW9kaWZpY2F0aW9uIiwiQXNzaWduUmF0ZVNoZWV0VG9Vc2VyR3JvdXAiLCJDYW5Td2l0Y2hOdW1iZXJCYXNlIiwiQ29tcGFueVZpZXdSYXRlIiwiRWRpdG9yQ29sdW1uRWRpdCIsIkNvbXBhbnlFZGl0Q2hhbm5lbEluUHJpY2VyT25OZXdQcmljaW5nIiwiRWRpdEFkbWluRmVlIiwiY2FuVXNlTWluUGF5bWVudFBlcmNlbnRhZ2UiLCJNYXJrZXRQcmljaW5nIiwiQ2xvc2luZ0Nvc3RBZG1pbiIsIkNoYW5nZURheXNMb2NrIiwiQnlwYXNzQ2FwIiwiQ29tcGFueUVkaXRSYXRlIiwiVmlld0F2ZXJhZ2VDcmVkaXQiLCJDYW5FZGl0UW1GaWx0ZXIiLCJMaWVuUHJpb3JpdHkiLCJDb21wYW55Vmlld09yaWdpbmFsUmF0ZUZyb21QcmljaW5nIiwiQ29tcGFueVVzZXJHcm91cFZpZXciLCJFZGl0Tm1sc0lkIiwiQ29tcGFueUNyZWF0ZVJhdGUiLCJDb21wYW55VXNlck1hcmtldGluZ01hbmFnZXIiLCJNdWx0aUNyaXRlcmlhUHJpY2VyVmlldyIsIkNvbXBhbnlFZGl0Q2hhbm5lbEluUHJpY2VyIiwiVmlld0FsdGVybmF0ZUNyZWRpdFNjb3JlIiwiQ29tcGFueVVzZXJTZWNvbmRhcnlNYXJrZXRpbmciLCJDYW5JbXBlcnNvbmF0ZUdyb3VwIiwiRWRpdEZIQUVuZG9yc2VtZW50RGF0ZSIsIlZpZXdDaGFubmVsIiwiVmlld1Byb2R1Y3RGaW5kZXIiLCJDb21wYW55Q3VzdG9tRmVlIiwiRXhwb3J0UHJpY2VSb2xlIiwiUGF5bWVudFNjaGVkdWxlIiwiRGlzYWJsZUNvbXBsaWFuY2VSdWxlcyIsIkNvbXBhbnlVc2VyUHJpY2VRdW90ZU1hbmFnZXIiLCJRTUJ5UGFzcyIsIlZpZXdMb2NrRGVzayIsIkVkaXRQcm9kdWN0RmluZGVyIiwiQ29tcGFueVZpZXdNYXJnaW5Hcm91cCIsIkF1dG9QcmljZU92ZXJyaWRlIiwiQ29tcGFueVVzZXJBcHByb3ZlUmF0ZVBlcmlvZE1vZGlmaWNhdGlvbiIsIkNvbXBhbnlVc2VyTWFuYWdlciIsIkNvbXBhbnlWaWV3QnJva2VycyIsIkNvbXBhbnlWaWV3TG9ncyIsIkNvbXBhbnlWaWV3UmV2aWV3cyIsIkNvbXBhbnlWaWV3Q29tcGFueSIsIkZhdm9yaXRlIiwiVmlld0FkbWluRmVlIiwiQ29tcGFueUNvbXBsaWFuY2VWaWV3IiwiTXVsdGlEaW1lbnNpb25Ob3RlUmF0ZSIsIkNvbXBhbnlVc2VyIiwiQnlwYXNzRXh0U3luYyIsIkVuYWJsZUV4cGVyaW1lbnRhbFZpZXciLCJDb21wYW55VXNlck1hcmtldGluZ0ZseWVyIiwiR292ZXJubWVudExvYW4iLCJDYW5JbXBlcnNvbmF0ZVVzZXIiLCJDb21wYW55Vmlld0xlbmRlcnMiLCJDb21wYW55VXNlck1hcmtldGluZ01pbmlQcmljZXIiLCJDb21wYW55UmVxdWVzdExlbmRlcnMiLCJDYW5FZGl0Q3VzdG9tUHJpY2VyIiwiVmlld0Z1bmRpbmdGZWUiLCJWaWV3VWZtaXBGZWUiLCJDb21wYW55RWRpdENvbXBhbnkiLCJMb2FuT2ZmaWNlclZpZXdEYXNoYm9hcmQiXSwiaW50ZWdyYXRpb25Ub2tlbiI6IkVsbGllIiwic3NvT25seSI6ZmFsc2UsImxvYW5HVUlEIjpudWxsLCJjb21wYW55SWQiOiI1ZTM4YmJkYzU2ZWVkMDRiYjgyNzE3YjkiLCJpc0NoYW5nZU9mQ2lyY3Vtc3RhbmNlIjpmYWxzZSwibGlua0lkIjoiNjVjZDI4Y2UyZjdlN2Q2OTE4NzM0MThjIiwidXNlRmVhdHVyZUdyb3VwIjpmYWxzZSwicGVyc29uIjp7ImZpcnN0bmFtZSI6IlRlc3QiLCJsYXN0bmFtZSI6IlNpZ21hIExvY2siLCJtb2JpbGUiOm51bGwsInBob25lIjoiIiwiYWRkcmVzcyI6eyJsb25naXR1ZGUiOm51bGwsImxhdGl0dWRlIjpudWxsLCJjZW5zdXN0cmFjdCI6IiIsInN0cmVldCI6IiIsInN0cmVldENvbnQiOiIiLCJjaXR5IjoiIiwiemlwIjoiIiwiemlwRXh0IjoiIiwic3RhdGUiOiIiLCJwcm92aW5jZSI6IiIsImNvdW50eSI6IiIsImNvdW50eU5hbWUiOiIiLCJjb3VudHJ5IjoiVVMiLCJjb3VudHlGaXBzIjoiIiwic3RhdGVGaXBzIjoiIiwibXNhIjpudWxsLCJkZWZhdWx0WmlwRmlwc0NvbWJvT25NaXNtYXRjaCI6ZmFsc2V9LCJlbWFpbCI6InN1cHBvcnRAbGVuZGVycHJpY2UuY29tIn0sImVsbGllVXNlcm5hbWUiOiJsb2NrZGVzayIsInNpdGVJZCI6bnVsbCwidXNlclR5cGUiOiJDb21wYW55VXNlciIsImxvYW5OdW1iZXIiOm51bGwsImV4dE9yZ0lkIjpudWxsLCJ0aW55QWNjZXNzVG9rZW4iOm51bGx9.aruacNhAF0NmvBxh3c96fYNDge5iwCHz8IzJ9scoe--WajbY-CkfW19LX_i5CSFVk1vc9MYqDC1pkmllo_H04P4uusXmZQnvbfzOFRkKZOQC6sPPdLVLoaB1wTJCFqdBH99-HaBpOPQkxf37yxFG9lIvf0IuLH43xQKjYnXqN_E9v-6BGKxlOfqjdKgs0oMUKJKoseQJeOh1m3pS4Uhg0mDV_2eDYE08mVLjOsTGmjzT6uo6-UOeKlMg3CBv7IFE0KPqB8hWBiWMLUX8-FQ7TDjntwyfr6667VYYVVDdF8_lcQnTGKYq7yvtA_5XJPPJ2nC58DH8gDveR-50ALUcuA
                - generic [ref=e22]: 
                - text: Rate Alerts
            - listitem [ref=e23]:
              - link "Quick Pricer" [ref=e24] [cursor=pointer]:
                - /url: "#/app/company/5e38bbdc56eed04bb82717b9/quickPricer"
                - generic [ref=e25]: 
                - text: Quick Pricer
            - listitem [ref=e26]:
              - link "Pipeline" [ref=e27] [cursor=pointer]:
                - /url: "#/app/company/5e38bbdc56eed04bb82717b9/pipeline"
                - generic [ref=e28]: 
                - text: Pipeline
            - listitem [ref=e29]:
              - link "Monitoring" [ref=e30] [cursor=pointer]:
                - /url: "#/app/company/5e38bbdc56eed04bb82717b9/monitorings"
                - generic [ref=e31]: 
                - text: Monitoring
            - listitem [ref=e32]:
              - link "Config" [ref=e33] [cursor=pointer]:
                - /url: "#/app/company/5e38bbdc56eed04bb82717b9/config"
                - generic [ref=e34]: 
                - text: Config
          - generic [ref=e35]:
            - button "Profile picture" [ref=e36] [cursor=pointer]:
              - img "Profile picture" [ref=e38]
            - text:      
      - text:          
    - generic [ref=e42]:
      - generic [ref=e43]:
        - generic [ref=e44]: 
        - text: Back
      - generic [ref=e47]:
        - generic [ref=e50]:
          - generic [ref=e51]: 
          - text: Pricer Configurations
        - generic [ref=e52]:
          - tablist [ref=e53]:
            - listitem [ref=e54]:
              - tab "Quick Pricer" [selected] [ref=e55] [cursor=pointer]
            - listitem [ref=e56]:
              - tab "Loan Pricer" [selected] [ref=e57] [cursor=pointer]
            - listitem [ref=e58]:
              - tab "LendingPad Pricer" [selected] [ref=e59] [cursor=pointer]
          - generic "Quick Pricer" [ref=e60]:
            - generic [ref=e62]:
              - generic [ref=e63]: Add/Edit Service Interruptions
              - generic [ref=e64]:
                - generic [ref=e65]: Default Configuration
                - generic [ref=e66]:
                  - list [ref=e67]:
                    - listitem [ref=e68]
                    - listitem [ref=e69]:
                      - generic [ref=e70]:
                        - generic [ref=e71]: Result Type
                        - generic [ref=e73]:
                          - generic [ref=e74]:
                            - radio "QM" [checked] [ref=e75]
                            - generic [ref=e76] [cursor=pointer]: QM
                          - generic [ref=e77]:
                            - radio "Non QM" [ref=e78]
                            - generic [ref=e79] [cursor=pointer]: Non QM
                    - listitem [ref=e80]:
                      - generic [ref=e83] [cursor=pointer]:
                        - generic [ref=e84]: 
                        - text: Dynamic Fields
                  - generic [ref=e85]:
                    - generic [ref=e86]:
                      - generic [ref=e87] [cursor=pointer]:
                        - generic [ref=e88]: 
                        - text: Pricer Options
                      - text:                                                 
                    - generic [ref=e89]:
                      - generic [ref=e90] [cursor=pointer]:
                        - generic [ref=e91]: 
                        - text: Pricing Result Group
                      - text:       
                    - generic [ref=e93] [cursor=pointer]:
                      - generic [ref=e94]: 
                      - text: Results Columns
                    - generic [ref=e95]:
                      - generic [ref=e96] [cursor=pointer]:
                        - generic [ref=e97]: 
                        - text: Search Fields
                      - text:               
                    - generic [ref=e98]:
                      - generic [ref=e99] [cursor=pointer]:
                        - generic [ref=e100]: 
                        - text: LOCK EVENTS
                      - text: 
                    - generic [ref=e101]:
                      - generic [ref=e102] [cursor=pointer]:
                        - generic [ref=e103]: 
                        - text: ENCOMPASS Mapping
                      - text: 
                  - generic [ref=e106]:
                    - generic [ref=e107]: "Current Config Version: 3970"
                    - generic [ref=e108]: "Jun 12, 2026/9:46 AM -- Modified by: Test Sigma Lock"
                    - button "View Version History" [ref=e109] [cursor=pointer]
              - generic [ref=e110]:
                - generic [ref=e111]:
                  - generic [ref=e112]: Iframe
                  - generic [ref=e114]:
                    - checkbox "Iframe Enabled Iframe" [checked] [ref=e115]
                    - generic [ref=e116]: Enabled
                - generic [ref=e117]:
                  - generic [ref=e118]: Iframe
                  - generic [ref=e120]:
                    - checkbox "Block if search name is empty" [ref=e121]
                    - generic [ref=e122]: Block if search name is empty
                - generic [ref=e123]:
                  - generic [ref=e124]: Callback URL
                  - textbox "Callback URL" [ref=e126]: https://lendingqb.com/lp-ppe-integration
                - generic [ref=e127]:
                  - generic [ref=e128]: Auth Type
                  - generic [ref=e130]:
                    - text: 
                    - combobox "Auth Type" [ref=e131]:
                      - option "None" [selected]
                      - option "Basic"
                - generic [ref=e132]:
                  - generic [ref=e133]: Allow Saving Search
                  - generic [ref=e135]:
                    - checkbox "Allow Saving Search Enabled" [checked] [ref=e136]
                    - generic [ref=e137]: Enabled
                - generic [ref=e138]:
                  - generic [ref=e139]: Allow Saving Pricing Result
                  - generic [ref=e141]:
                    - checkbox "Allow Saving Pricing Result Enabled" [checked] [ref=e142]
                    - generic [ref=e143]: Enabled
              - generic [ref=e145]:
                - generic [ref=e146]: Custom UI
                - generic [ref=e148]:
                  - checkbox "Custom UI Enabled" [ref=e149]
                  - generic [ref=e150]: Enabled
          - generic "Loan Pricer":                                                                                                                                                                            
          - generic "LendingPad Pricer":                                                  
        - button "Save" [ref=e153] [cursor=pointer]
  - dialog [active] [ref=e155]:
    - document:
      - generic [ref=e158]:
        - generic [ref=e159]:
          - heading " Alert" [level=5] [ref=e160]:
            - generic [ref=e161]:
              - generic [ref=e162]: 
              - text: Alert
          - button "Close" [ref=e163] [cursor=pointer]:
            - generic [ref=e165]: 
        - generic [ref=e167]: "No content to map due to end-of-input at [Source: (String)\"\"; line: 1, column: 0]"
        - button "ok" [ref=e169] [cursor=pointer]:
          - generic [ref=e171]: ok
```

# Test source

```ts
  1   | // [POM-APPLIED]
  2   | import { test, expect } from '@playwright/test';
  3   | import * as stepGroups from '../../../../src/helpers/step-groups';
  4   | import { LenderPricePage } from '../../../../src/pages/ext-web/lender-price';
  5   | import { PpeextldPage } from '../../../../src/pages/ext-web/ppeextld';
  6   | import { PpeExtLdPage } from '../../../../src/pages/ext-web/ppe-ext-ld';
  7   | import { PpeextloPage } from '../../../../src/pages/ext-web/ppeextlo';
  8   | import { testDataManager } from 'testdata/TestDataManager';
  9   | import { Logger as log } from '../../../../src/helpers/log-helper';
  10  | import { APP_CONSTANTS } from 'src/constant/app-constants';
  11  | 
  12  | const TC_ID = 'REG_TS01_TC06_01';
  13  | const TC_TITLE = 'Create or send PDF button appears at the bottom with the select';
  14  | 
  15  | const profileName = "Regression Sheet Details1 [Quick Pricer]";
  16  | const profile = testDataManager.getProfileByName(profileName);
  17  | 
  18  | if (profile && profile.data) {
  19  |   profile.data.forEach((dataRow, index) => {
  20  |     test.describe(`Quick Pricer Module- Row ${index + 1}`, () => {
  21  | 
  22  |       let lenderPricePage: LenderPricePage;
  23  |       let ppeExtLdPage: PpeExtLdPage;
  24  |       let ppeextldPage: PpeextldPage;
  25  | 
  26  | 
  27  |       const vars: Record<string, string> = {
  28  |         "Zip code 1": dataRow["Zip code 1"],
  29  |         "Zip code 2": dataRow["Zip code 2"],
  30  |         "password": dataRow["password"],
  31  |         "UserName": dataRow["UserName"],
  32  |       };
  33  |       test.beforeEach(async ({ page }) => {
  34  | 
  35  |         ppeExtLdPage = new PpeExtLdPage(page);
  36  |         ppeextldPage = new PpeextldPage(page);
  37  |         lenderPricePage = new LenderPricePage(page);
  38  | 
  39  |       });
  40  | 
  41  |       test(`${TC_ID} - ${TC_TITLE}`, async ({ page }) => {
  42  | 
  43  |         // ─── TC Start ─────────────────────────────────────────────────────────
  44  |         log.tcStart(TC_ID, TC_TITLE);
  45  | 
  46  |         try {
  47  | 
  48  |           // ── Step 1: Login ──────────────────────────────────────────────────
  49  |           log.step('Login to EXT Application');
  50  |           try {
  51  |             await stepGroups.stepGroup_Login_To_EXT_Application(page, vars);
  52  |             log.stepPass('Login to EXT Application successful');
  53  |           } catch (e) {
  54  |             await log.stepFail(page, 'Login to EXT Application failed');
  55  |             throw e;
  56  |           }
  57  |           // if (true) /* Element Error POPUP is visible */ {
  58  |           //   await configPage.Ok_Button_In_Popup.click();
  59  |           // }
  60  |           await ppeExtLdPage.Config_Icon.waitFor({ state: 'attached', timeout: 10000 }).catch(() => null);
  61  |           if (await ppeExtLdPage.Config_Icon.isVisible()) {
  62  |             log.step('Navigate to Quick Pricer Configuration');
  63  |             try {
  64  |               // await expect(ppeExtLdPage.Config_Icon).toBeVisible();
  65  |               await ppeExtLdPage.Config_Icon.click();
  66  |               await expect(ppeExtLdPage.Pricer_Configs).toBeVisible();
  67  |               await expect(ppeextldPage.Quick_Pricer_Configuration_In_Pricer_Configs).toBeVisible();
  68  |               await ppeextldPage.Quick_Pricer_Configuration_In_Pricer_Configs.click();
  69  |               log.stepPass('Navigation to Quick Pricer Configuration successful');
  70  |             } catch (e) {
  71  |               await log.stepFail(page, 'Navigation to Quick Pricer Configuration failed');
  72  |               throw e;
  73  |             }
  74  | 
  75  |             log.step('Configure Results Columns');
  76  |             try {
  77  |               await expect(ppeextldPage.Pricer_Options_In_Default_Configuration).toBeVisible();
  78  |               await ppeExtLdPage.Results_Columns.scrollIntoViewIfNeeded();
> 79  |               await ppeExtLdPage.Results_Columns.click();
      |                                                  ^ TimeoutError: locator.click: Timeout 35000ms exceeded.
  80  |               await lenderPricePage.Show_Price_Label_Checkbox_BothUI.scrollIntoViewIfNeeded();
  81  | 
  82  |               if (await lenderPricePage.Show_Price_Label_Checkbox_BothUI.isChecked()) {
  83  |                 await expect(lenderPricePage.Show_Price_Label_Checkbox_BothUI).toBeVisible();
  84  |                 console.log('show price checkbox is checked');
  85  |                 if (await lenderPricePage.Show_Price_In_Dollars_Checkbox.isChecked()) {
  86  |                   await expect(lenderPricePage.Show_Price_In_Dollars_Checkbox).toBeVisible();
  87  |                 } else {
  88  |                   await lenderPricePage.Show_Price_In_Dollars_Checkbox.evaluate(el => (el as HTMLElement).click());
  89  |                 }
  90  |               } else {
  91  |                 console.log('show price checkbox is APP_CONSTANTS.UNCHECKED;');
  92  | 
  93  |                 await expect(lenderPricePage.Show_Price_Label_Checkbox_BothUI).toBeVisible();
  94  |                 await lenderPricePage.Show_Price_Label_Checkbox_BothUI.evaluate(el => (el as HTMLElement).click());
  95  |                 if (await lenderPricePage.Show_Price_In_Dollars_Checkbox.isChecked()) {
  96  |                   await expect(lenderPricePage.Show_Price_In_Dollars_Checkbox).toBeVisible();
  97  |                 } else {
  98  |                   await lenderPricePage.Show_Price_In_Dollars_Checkbox.evaluate(el => (el as HTMLElement).click());
  99  |                 }
  100 |               }
  101 |               log.stepPass('Results Columns configuration updated');
  102 |             } catch (e) {
  103 |               await log.stepFail(page, 'Configure Results Columns failed');
  104 |               throw e;
  105 |             }
  106 | 
  107 |             log.step('Update General Pricer Settings');
  108 |             try {
  109 |               await ppeextldPage.Pricer_Options_In_Default_Configuration.scrollIntoViewIfNeeded();
  110 |               await ppeextldPage.Pricer_Options_In_Default_Configuration.click();
  111 |               await expect(ppeExtLdPage.General_Pricer_Settings_In_Config).toBeVisible();
  112 |               await ppeExtLdPage.Default_ZipCode_Input.scrollIntoViewIfNeeded();
  113 |               await ppeExtLdPage.Default_ZipCode_Input.clear();
  114 |               await ppeExtLdPage.Default_ZipCode_Input.fill(vars["Zip code 2"]);
  115 |               log.stepPass('General Pricer Settings updated');
  116 |             } catch (e) {
  117 |               await log.stepFail(page, 'Update General Pricer Settings failed');
  118 |               throw e;
  119 |             }
  120 | 
  121 |             log.step('Update Document Generation Settings');
  122 |             try {
  123 |               await ppeextldPage.Document_Generation_Settings_In_Quick_pricer.scrollIntoViewIfNeeded();
  124 |               await expect(ppeextldPage.Document_Generation_Settings_In_Quick_pricer).toBeVisible();
  125 |               await expect(lenderPricePage.Allow_Pricing_Comparison_Label).toBeVisible();
  126 |               if (await lenderPricePage.Allow_Pricing_Comparison_Label.isChecked()) {
  127 |                 await expect(lenderPricePage.Allow_Pricing_Comparison_Label).toBeVisible();
  128 |                 vars["AllowPricing"] = APP_CONSTANTS.CHECKED;
  129 |                 await stepGroups.stepGroup_SG_Custom_UI_Disabled(page, vars);
  130 |               } else {
  131 |                 await expect(lenderPricePage.Allow_Pricing_Comparison_Label).toBeVisible();
  132 |                 vars["AllowPricing"] = "APP_CONSTANTS.UNCHECKED;";
  133 |                 await stepGroups.stepGroup_SG_Custom_UI_Disabled(page, vars);
  134 |               }
  135 |               log.stepPass('Document Generation Settings updated');
  136 |             } catch (e) {
  137 |               await log.stepFail(page, 'Update Document Generation Settings failed');
  138 |               throw e;
  139 |             }
  140 |           }
  141 | 
  142 |           log.step('Verify Quick Pricer Results');
  143 |           try {
  144 |             // if (String(vars["AllowPricing"]) === String(APP_CONSTANTS.CHECKED)) {
  145 |             if (vars["AllowPricing"] === APP_CONSTANTS.CHECKED) {
  146 |               await stepGroups.stepGroup_SG_Quick_Pricer_Verification(page, vars);
  147 |               await expect(ppeExtLdPage.Price_Edit_Checkboxview_details_search_result_view).toBeVisible();
  148 |             } else if (String(vars["AllowPricing"]) === String("APP_CONSTANTS.UNCHECKED;")) {
  149 |               await stepGroups.stepGroup_SG_Quick_Pricer_Verification(page, vars);
  150 |               await expect(ppeExtLdPage.Price_Edit_Checkboxview_details_search_result_view).toBeVisible();
  151 |               if (await ppeExtLdPage.Config_Icon.isVisible()) {
  152 |                 await stepGroups.stepGroup_Verifying_document_Generation_Settings_in_Pricing_Configurat(page, vars);
  153 |                 await ppeextldPage.Document_Generation_Settings_In_Quick_pricer.click();
  154 |                 await lenderPricePage.Allow_Pricing_Comparison_Checkbox.evaluate(el => (el as HTMLElement).click());
  155 |                 await expect(lenderPricePage.Allow_Pricing_Comparison_Checkbox).toBeVisible();
  156 |                 vars["Allow Pricing"] = APP_CONSTANTS.CHECKED;
  157 |               }
  158 |               await stepGroups.stepGroup_SG_Save_In_Success_Alert(page, vars);
  159 |             }
  160 |             log.stepPass('Quick Pricer Verification completed');
  161 |           } catch (e) {
  162 |             await log.stepFail(page, 'Quick Pricer Verification failed');
  163 |             throw e;
  164 |           }
  165 | 
  166 |           log.step('Logout from application');
  167 |           try {
  168 |             await stepGroups.stepGroup_SG_Logout(page, vars);
  169 |             log.stepPass('Logout successful');
  170 |           } catch (e) {
  171 |             await log.stepFail(page, 'Logout failed');
  172 |             throw e;
  173 |           }
  174 | 
  175 |           // ─── TC End: PASS ──────────────────────────────────────────────────
  176 |           log.tcEnd('PASS');
  177 | 
  178 |         } catch (e) {
  179 |           // ─── TC End: FAIL — capture screenshot + video/trace paths ─────────
```