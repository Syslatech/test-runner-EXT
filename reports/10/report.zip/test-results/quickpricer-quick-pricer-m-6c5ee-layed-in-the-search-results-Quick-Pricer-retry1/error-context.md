# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ext-web/quickpricer/quick-pricer-module/reg_ts01_tc01_default-zip-code-and-city-is-displayed-in-the-search-results-1565.spec.ts >> Quick Pricer Module - Row 2 >> REG_TS01_TC01 - Default zip code and city is displayed in the search results
- Location: tests/ext-web/quickpricer/quick-pricer-module/reg_ts01_tc01_default-zip-code-and-city-is-displayed-in-the-search-results-1565.spec.ts:46:17

# Error details

```
Error: browserType.launch: Executable doesn't exist at /ms-playwright/chromium_headless_shell-1217/chrome-headless-shell-linux64/chrome-headless-shell
╔════════════════════════════════════════════════════════╗
║ Looks like Playwright was just updated to 1.59.1.      ║
║ Please update docker image as well.                    ║
║ -  current: mcr.microsoft.com/playwright:v1.52.0-jammy ║
║ - required: mcr.microsoft.com/playwright:v1.59.1-jammy ║
║                                                        ║
║ <3 Playwright Team                                     ║
╚════════════════════════════════════════════════════════╝
```